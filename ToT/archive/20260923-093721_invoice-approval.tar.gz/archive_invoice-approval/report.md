# 流程测试报告 · invoice-approval · 2026-09-23 09:37:21

> **生成方式**：`ToT/sop/archive_flow.py` 自动生成
> **目的**：测试数据归档 + 跨环境分享 + 历史快照

---

## 1. 流程基本信息

- **name**: `invoice-approval`
- **displayName**: 发票审批：员工提交 → 财务初审 → 主管复核 → 出纳付款 → 完成
- **version**: 0.5
- **节点数**: 6
- **边数**: 6
- **节点类型**: {'start': 1, 'task': 3, 'decision': 1, 'end': 1}

## 2. 测试配置（来自 tests.json）

- **operator**: `u_fdp_pm`
- **scenarios**: `small:{"amount":500,"purpose":"办公"}|big:{"amount":8000,"purpose":"服务器"}|reject:{"amount":8000,"purpose":"服务器"}:5:金额异常，需补充材料`
- **top_vars**: `{'tf_manager': 'u_bob', 'tf_treasurer': 'u_carol'}`
- **baseline**: `test_invoice-approval_baseline_*.json`

## 3. 测试结果（最新 baseline + dashboard）

- **baseline timestamp**: 20260923074628
- **scenarios**: 3
- **results**: 3
  - `small` → state=`DONE`
  - `big` → state=`DONE`
  - `reject` → state=`DONE`

- **dashboard all_passed**: True
- **total flows**: 2
- **total scenarios**: 6

## 4. 组织架构图（来自 SPI `/api/spi/depts`）

- **研发部** (D01) — size=3, leader=`u_rd_dir`, main_leader=`u_cto`
- **前端组** (D02) — size=3, leader=`u_fe_lead`, main_leader=`u_rd_dir`
- **后端组** (D03) — size=4, leader=`u_be_lead`, main_leader=`u_rd_dir`
- **架构组** (D04) — size=1, leader=`u_arch`, main_leader=`u_cto`
- **总经办** (D99) — size=2, leader=`u_ceo`, main_leader=`u_ceo`
- **FDEP协作组** (DFDEP) — size=1, leader=`u_fdp_pm`, main_leader=`u_fdp_pm`

## 5. 关键用户（来自 SPI `/api/spi/users`）

| uid | 姓名 | 岗位 | 部门 | 角色 |
|-----|------|------|------|------|
| `u_arch` | 陈静 | 架构师 (P8) | D04 | architect |
| `u_be_eng` | 钱琳 | 后端工程师 (P5) | D03 | engineer |
| `u_be_lead` | 孙婷 | 后端组长 (P7) | D03 | tech_lead |
| `u_be_senior1` | 吴杰 | 后端高级工程师 (P6) | D03 | senior_engineer |
| `u_be_senior2` | 郑浩 | 后端高级工程师 (P6) | D03 | senior_engineer |
| `u_ceo` | 张伟 | 首席执行官 (P10) | D99 | ceo |
| `u_cto` | 李娜 | 首席技术官 (P9) | D99 | cto |
| `u_fdp_pm` | 占位·待分配 | FDEP 流程占位 (P5) | DFDEP | fdep_intake, fdep_rml, fdep_arch, fdep_dev, fdep_review, fdep_kb |
| `u_fe_eng` | 周磊 | 前端工程师 (P5) | D02 | engineer |
| `u_fe_lead` | 刘洋 | 前端组长 (P7) | D02 | tech_lead |
| `u_fe_senior` | 赵敏 | 前端高级工程师 (P6) | D02 | senior_engineer |
| `u_qa_eng` | 蒋雷 | QA 工程师 (P5) | D01 | qa_engineer |
| `u_qa_lead` | 冯雪 | QA 组长 (P7) | D01 | qa_engineer |
| `u_rd_dir` | 王强 | 研发总监 (P8) | D01 | rd_director |

## 6. 改进建议（基于 27+ 圈 EA 飞轮经验）

- ✅ 已用 actor resolver 3 种语法（`@role:` / 顶级变量 / `applicant`）
- ✅ 已用 decision mem 协议（comment / decision_reason / decision_memo）
- ✅ 已用驳回机制（`submitType=5 RE_APPLY` 而非 `submitType=2 REJECT`）
- ⚠️ 建议：CI 集成 tdd-flow 4 模式（dry-run / baseline-only / 实跑 / only-changed）
- ⚠️ 建议：dashboard 自动生成 + time filter + sparkline
- 💡 进阶：跨环境兼容性测试（local-memory → local-pg → org-server → customer-test）

## 7. 附件清单


## 8. 附件清单

- `flows/invoice-approval.json`
- `flows/invoice-approval/CHANGELOG.md`
- `flows/invoice-approval/RESPONSES.md`
- `flows/invoice-approval/ROLES.md`
- `flows/invoice-approval/NODES.md`
- `flows/invoice-approval/README.md`
- `flows/invoice-approval/job_cards/job_card_pay.md`
- `flows/invoice-approval/job_cards/job_card_submit.md`
- `flows/invoice-approval/job_cards/job_card_approve.md`
- `flows/invoice-approval/job_cards/job_card_decision_amount.md`
- `tdd/test_invoice-approval_baseline_v0_3_20260923072751.json`
- `tdd/test_invoice-approval_baseline_v0_4_20260923073925.json`
- `tdd/test_invoice-approval_baseline_v0_5_20260923074628.json`
- `tdd/test_invoice-approval_baseline_v0_3_20260923072751.md`
- `tdd/test_invoice-approval_baseline_v0_4_20260923073925.md`
- `tdd/test_invoice-approval_baseline_v0_5_20260923074628.md`
- `tdd/test_invoice-approval_20260923081429.json`
- `tdd/test_invoice-approval_20260923081436.json`
- `tdd/test_invoice-approval_20260923081429.md`
- `tdd/test_invoice-approval_20260923081436.md`
- `tests.json`
